// LinkedIn Comment Generator - Background Service Worker

// Listen for installation
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    // Set default settings on first install
    chrome.storage.sync.set({
      webhookUrl: 'https://n8n.xdo.it.com/webhook/LinkedIn_Comments',
      maxComments: 50,
      defaultTone: 'Conversational'
    });
    
    console.log('LinkedIn Comment Generator installed');
  }
});

// Handle messages from popup or content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getCurrentTab') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      sendResponse({ tab: tabs[0] });
    });
    return true; // Keep channel open for async response
  }
  
  if (request.action === 'openLinkedIn') {
    chrome.tabs.create({ url: 'https://www.linkedin.com' });
    sendResponse({ success: true });
  }
});
