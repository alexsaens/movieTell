// LinkedIn Comment Generator - Content Script
// This script runs on LinkedIn pages and can inject UI elements

(function() {
  'use strict';

  // Only run on LinkedIn
  if (!window.location.hostname.includes('linkedin.com')) return;

  // Add floating action button to post pages
  function addFloatingButton() {
    // Check if we're on a post page
    if (!isPostPage()) return;

    // Don't add if already exists
    if (document.getElementById('lcg-fab')) return;

    const fab = document.createElement('button');
    fab.id = 'lcg-fab';
    fab.className = 'lcg-floating-btn';
    fab.innerHTML = `
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M20 2H4C2.9 2 2 2.9 2 4V22L6 18H20C21.1 18 22 17.1 22 16V4C22 2.9 21.1 2 20 2ZM20 16H5.17L4 17.17V4H20V16Z" fill="currentColor"/>
        <path d="M12 3V6M12 18V21M6 12H3M21 12H18M18.364 5.636L16.243 7.757M7.757 16.243L5.636 18.364M18.364 18.364L16.243 16.243M7.757 7.757L5.636 5.636" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
      </svg>
      <span class="lcg-tooltip">Generate AI Comment</span>
    `;
    
    fab.addEventListener('click', () => {
      // Send message to open popup
      chrome.runtime.sendMessage({ 
        action: 'openPopupWithUrl',
        url: window.location.href
      });
    });

    document.body.appendChild(fab);
  }

  function isPostPage() {
    return window.location.href.includes('/posts/') || 
           window.location.href.includes('/feed/update/');
  }

  // Initialize on page load
  function init() {
    addFloatingButton();
  }

  // Watch for URL changes (LinkedIn is a SPA)
  let lastUrl = location.href;
  new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
      lastUrl = url;
      setTimeout(init, 1000); // Wait for page to load
    }
  }).observe(document, { subtree: true, childList: true });

  // Initial load
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    setTimeout(init, 1000);
  }
})();
