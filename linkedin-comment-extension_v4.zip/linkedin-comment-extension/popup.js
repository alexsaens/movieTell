// LinkedIn Comment Generator - Popup Script

document.addEventListener('DOMContentLoaded', initializePopup);

// State
let settings = {
  webhookUrl: 'https://n8n.xdo.it.com/webhook/LinkedIn_Comments',
  maxComments: 50,
  defaultTone: 'Conversational'
};

// DOM Elements
const elements = {
  postUrl: null,
  numResponses: null,
  tone: null,
  generateBtn: null,
  resultsSection: null,
  resultsContainer: null,
  sentimentSection: null,
  sentimentContent: null,
  settingsPanel: null,
  toast: null
};

function initializePopup() {
  // Cache DOM elements
  elements.postUrl = document.getElementById('postUrl');
  elements.numResponses = document.getElementById('numResponses');
  elements.tone = document.getElementById('tone');
  elements.generateBtn = document.getElementById('generateBtn');
  elements.resultsSection = document.getElementById('resultsSection');
  elements.resultsContainer = document.getElementById('resultsContainer');
  elements.sentimentSection = document.getElementById('sentimentSection');
  elements.sentimentContent = document.getElementById('sentimentContent');
  elements.settingsPanel = document.getElementById('settingsPanel');
  elements.toast = document.getElementById('toast');

  // Load settings
  loadSettings();

  // Setup event listeners
  setupEventListeners();

  // Try to auto-fill URL from current tab
  autoFillCurrentTab();
}

function setupEventListeners() {
  // Generate button
  elements.generateBtn.addEventListener('click', handleGenerate);

  // Use current tab button
  document.getElementById('useCurrentTab').addEventListener('click', () => {
    autoFillCurrentTab(true);
  });

  // Tone pills
  document.querySelectorAll('.tone-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      const tone = pill.dataset.tone;
      selectTone(tone);
    });
  });

  // Tone select change
  elements.tone.addEventListener('change', (e) => {
    selectTone(e.target.value);
  });

  // Settings
  document.getElementById('settingsBtn').addEventListener('click', openSettings);
  document.getElementById('closeSettings').addEventListener('click', closeSettings);
  document.getElementById('settingsOverlay').addEventListener('click', closeSettings);
  document.getElementById('saveSettings').addEventListener('click', saveSettings);

  // Copy all button
  document.getElementById('copyAllBtn').addEventListener('click', copyAllComments);

  // Enter key on URL input
  elements.postUrl.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      handleGenerate();
    }
  });

  // Pop out button
  document.getElementById('popOutBtn').addEventListener('click', popOutWindow);

  // Load any saved results
  loadSavedResults();
}

function selectTone(tone) {
  // Update select
  elements.tone.value = tone;

  // Update pills
  document.querySelectorAll('.tone-pill').forEach(pill => {
    pill.classList.toggle('active', pill.dataset.tone === tone);
  });
}

async function autoFillCurrentTab(showToast = false) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (tab && tab.url && tab.url.includes('linkedin.com')) {
      // Check if it's a post URL
      if (tab.url.includes('/posts/') || tab.url.includes('/feed/update/')) {
        elements.postUrl.value = tab.url;
        if (showToast) {
          showNotification('Current tab URL loaded', 'success');
        }
      } else if (showToast) {
        showNotification('Navigate to a LinkedIn post first', 'info');
      }
    } else if (showToast) {
      showNotification('Not a LinkedIn page', 'error');
    }
  } catch (error) {
    console.error('Error getting current tab:', error);
    if (showToast) {
      showNotification('Could not get current tab', 'error');
    }
  }
}

async function handleGenerate() {
  const url = elements.postUrl.value.trim();
  
  if (!url) {
    showNotification('Please enter a LinkedIn post URL', 'error');
    elements.postUrl.focus();
    return;
  }

  if (!isValidLinkedInUrl(url)) {
    showNotification('Please enter a valid LinkedIn post URL', 'error');
    return;
  }

  if (!settings.webhookUrl) {
    showNotification('Please configure your n8n webhook URL in settings', 'error');
    openSettings();
    return;
  }

  // Start loading state
  setLoading(true);

  try {
    const response = await fetch(settings.webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        'LinkedIn Post URL': url,
        'Number of Response Options': elements.numResponses.value,
        'Tone': elements.tone.value,
        'maxComments': settings.maxComments
      })
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    displayResults(data);
    saveResults(data); // Save results to storage
    showNotification('Comments generated successfully!', 'success');

  } catch (error) {
    console.error('Error generating comments:', error);
    showNotification('Failed to generate comments. Check your webhook URL.', 'error');
    
    // Show error in results area
    elements.resultsSection.classList.add('visible');
    elements.resultsContainer.innerHTML = `
      <div class="error-message">
        <strong>Error:</strong> ${error.message || 'Failed to connect to the webhook. Please check your settings and try again.'}
      </div>
    `;
  } finally {
    setLoading(false);
  }
}

function isValidLinkedInUrl(url) {
  try {
    const parsed = new URL(url);
    return parsed.hostname.includes('linkedin.com') && 
           (url.includes('/posts/') || url.includes('/feed/update/'));
  } catch {
    return false;
  }
}

function setLoading(isLoading) {
  elements.generateBtn.classList.toggle('loading', isLoading);
  elements.generateBtn.disabled = isLoading;
}

function displayResults(data) {
  elements.resultsSection.classList.add('visible');
  
  // Parse the output - it could be a string or object depending on your n8n setup
  let output = typeof data === 'string' ? data : (data.output || data.text || JSON.stringify(data));
  
  // Parse the options from the output
  const comments = parseComments(output);
  const summary = parseSummary(output);
  const commentCount = parseCommentCount(output);
  
  // Render comment cards
  elements.resultsContainer.innerHTML = comments.map((comment, index) => `
    <div class="result-card" data-index="${index}">
      <div class="result-header">
        <span class="result-number">${index + 1}</span>
        <div class="result-actions">
          <button class="action-btn copy-btn" data-comment="${escapeHtml(comment)}" title="Copy to clipboard">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
              <path d="M8 4V16C8 17.1 8.9 18 10 18H18C19.1 18 20 17.1 20 16V7.83C20 7.3 19.79 6.79 19.41 6.42L16.58 3.59C16.21 3.21 15.7 3 15.17 3H10C8.9 3 8 3.9 8 4ZM16 8V4.5L19.5 8H16Z" fill="currentColor"/>
              <path d="M4 8V20C4 21.1 4.9 22 6 22H14V20H6V8H4Z" fill="currentColor"/>
            </svg>
          </button>
        </div>
      </div>
      <p class="result-text">${escapeHtml(comment)}</p>
    </div>
  `).join('');

  // Add copy event listeners
  document.querySelectorAll('.copy-btn').forEach(btn => {
    btn.addEventListener('click', () => copyComment(btn));
  });

  // Render sentiment summary with comment count
  if (summary) {
    const countBadge = commentCount ? `<div class="comment-count-badge">📊 ${commentCount} comments analyzed</div>` : '';
    elements.sentimentContent.innerHTML = `${countBadge}<p>${escapeHtml(summary)}</p>`;
  }
}

function parseComments(output) {
  const comments = [];
  
  // Try to parse OPTION X: format
  const optionRegex = /\*\*OPTION\s*(\d+):\*\*\s*([\s\S]*?)(?=\*\*OPTION\s*\d+:|\*\*Summary|\*\*Number of Comments|$)/gi;
  let match;
  
  while ((match = optionRegex.exec(output)) !== null) {
    const comment = match[2].trim();
    if (comment) {
      comments.push(comment);
    }
  }
  
  // If no options found, try numbered format
  if (comments.length === 0) {
    const numberedRegex = /(?:^|\n)\s*(\d+)[.):]\s*([\s\S]*?)(?=\n\s*\d+[.)]|\*\*Summary|$)/gi;
    while ((match = numberedRegex.exec(output)) !== null) {
      const comment = match[2].trim();
      if (comment && comment.length > 20) {
        comments.push(comment);
      }
    }
  }

  // Fallback: just return the whole output as one comment
  if (comments.length === 0 && output.trim()) {
    comments.push(output.trim());
  }

  return comments;
}

function parseSummary(output) {
  // Try to extract summary section (stop at Number of Comments or end)
  const summaryMatch = output.match(/\*\*Summary\*\*\s*([\s\S]*?)(?=\*\*Number of Comments\*\*|---|$)/i);
  if (summaryMatch) {
    return summaryMatch[1].trim();
  }
  return null;
}

function parseCommentCount(output) {
  const countMatch = output.match(/\*\*Number of Comments\*\*\s*(\d+)/i);
  if (countMatch) {
    return parseInt(countMatch[1], 10);
  }
  return null;
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

async function copyComment(btn) {
  const comment = btn.dataset.comment;
  
  try {
    await navigator.clipboard.writeText(comment);
    btn.classList.add('copied');
    showNotification('Comment copied!', 'success');
    
    setTimeout(() => {
      btn.classList.remove('copied');
    }, 2000);
  } catch (error) {
    showNotification('Failed to copy', 'error');
  }
}

async function copyAllComments() {
  const comments = [];
  document.querySelectorAll('.result-text').forEach(el => {
    comments.push(el.textContent);
  });
  
  if (comments.length === 0) {
    showNotification('No comments to copy', 'error');
    return;
  }
  
  try {
    await navigator.clipboard.writeText(comments.join('\n\n---\n\n'));
    showNotification('All comments copied!', 'success');
  } catch (error) {
    showNotification('Failed to copy', 'error');
  }
}

// Settings Management
async function loadSettings() {
  try {
    const stored = await chrome.storage.sync.get(['webhookUrl', 'maxComments', 'defaultTone']);
    
    settings.webhookUrl = stored.webhookUrl || 'https://n8n.xdo.it.com/webhook/LinkedIn_Comments';
    settings.maxComments = stored.maxComments || 50;
    settings.defaultTone = stored.defaultTone || 'Conversational';
    
    // Apply default tone
    selectTone(settings.defaultTone);
    
    // Populate settings form
    document.getElementById('webhookUrl').value = settings.webhookUrl;
    document.getElementById('maxComments').value = settings.maxComments;
    document.getElementById('defaultTone').value = settings.defaultTone;
    
  } catch (error) {
    console.error('Error loading settings:', error);
  }
}

async function saveSettings() {
  const webhookUrl = document.getElementById('webhookUrl').value.trim();
  const maxComments = parseInt(document.getElementById('maxComments').value, 10);
  const defaultTone = document.getElementById('defaultTone').value;
  
  // Validate
  if (webhookUrl && !isValidUrl(webhookUrl)) {
    showNotification('Please enter a valid webhook URL', 'error');
    return;
  }
  
  if (maxComments < 10 || maxComments > 200) {
    showNotification('Max comments must be between 10 and 200', 'error');
    return;
  }
  
  // Save
  settings.webhookUrl = webhookUrl;
  settings.maxComments = maxComments;
  settings.defaultTone = defaultTone;
  
  try {
    await chrome.storage.sync.set(settings);
    selectTone(defaultTone);
    closeSettings();
    showNotification('Settings saved!', 'success');
  } catch (error) {
    showNotification('Failed to save settings', 'error');
  }
}

function isValidUrl(string) {
  try {
    new URL(string);
    return true;
  } catch {
    return false;
  }
}

function openSettings() {
  elements.settingsPanel.classList.add('visible');
}

function closeSettings() {
  elements.settingsPanel.classList.remove('visible');
}

// Toast Notifications
function showNotification(message, type = 'info') {
  const toast = elements.toast;
  toast.querySelector('.toast-message').textContent = message;
  toast.className = `toast ${type} visible`;
  
  setTimeout(() => {
    toast.classList.remove('visible');
  }, 3000);
}

// Pop out to standalone window
function popOutWindow() {
  const width = 500;
  const height = 700;
  const left = (screen.width - width) / 2;
  const top = (screen.height - height) / 2;
  
  chrome.windows.create({
    url: chrome.runtime.getURL('popup.html'),
    type: 'popup',
    width: width,
    height: height,
    left: Math.round(left),
    top: Math.round(top)
  });
}

// Save results to storage
async function saveResults(data) {
  try {
    await chrome.storage.local.set({
      lastResults: data,
      lastResultsTime: Date.now()
    });
  } catch (error) {
    console.error('Error saving results:', error);
  }
}

// Load saved results on popup open
async function loadSavedResults() {
  try {
    const stored = await chrome.storage.local.get(['lastResults', 'lastResultsTime']);
    
    if (stored.lastResults) {
      // Only show results from the last hour
      const oneHour = 60 * 60 * 1000;
      if (Date.now() - stored.lastResultsTime < oneHour) {
        displayResults(stored.lastResults);
        showNotification('Previous results restored', 'info');
      }
    }
  } catch (error) {
    console.error('Error loading saved results:', error);
  }
}

// Clear saved results
async function clearSavedResults() {
  try {
    await chrome.storage.local.remove(['lastResults', 'lastResultsTime']);
  } catch (error) {
    console.error('Error clearing results:', error);
  }
}
