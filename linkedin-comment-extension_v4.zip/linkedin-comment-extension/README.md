# LinkedIn Comment Generator - Chrome Extension

A sleek Chrome extension that generates intelligent, AI-powered comment responses for LinkedIn posts using your n8n automation workflow.

## Features

- 🎯 **Smart URL Detection** - Automatically detects LinkedIn post URLs from your current tab
- 🎨 **5 Tone Options** - Professional, Conversational, Creative, Geeky, or Confrontational
- 📊 **Sentiment Analysis** - Get a summary of existing comment sentiment
- 📋 **One-Click Copy** - Copy individual comments or all at once
- 🌙 **Modern Dark Theme** - Beautiful, eye-friendly interface
- ⚡ **Floating Action Button** - Quick access button appears on LinkedIn post pages

## Installation

### 1. Download the Extension

Download or clone this extension folder to your computer.

### 2. Load in Chrome

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable **Developer mode** (toggle in top-right corner)
3. Click **Load unpacked**
4. Select the `linkedin-comment-extension` folder
5. The extension icon should appear in your toolbar

### 3. Configure Your n8n Webhook

1. Click the extension icon to open it
2. Click the ⚙️ settings icon (top-right)
3. Enter your **n8n Webhook URL** (the URL from your LinkedIn Comment Form trigger node)
4. Adjust **Max Comments to Analyze** if needed (default: 50)
5. Set your **Default Tone** preference
6. Click **Save Settings**

## n8n Workflow Updates

### Increasing Comment Limit

The Apify actor you're using (`supreme_coder/linkedin-post`) has a known limitation of ~10 comments per post. Here are your options:

#### Option 1: Use a Different Apify Actor (Recommended)

Switch to `harvestapi/linkedin-post-search` or `harvestapi/linkedin-profile-posts` which support the `maxComments` parameter:

```json
{
  "urls": ["{{ $json.postUrl }}"],
  "maxComments": 100,
  "deepScrape": true
}
```

Set `maxComments` to `0` to scrape ALL comments (be aware of API costs).

#### Option 2: Use a Dedicated Comment Scraper

Use `curious_coder/linkedin-comment-scraper` specifically for comments:
- Supports unlimited comments
- More cost-effective for comment-heavy scraping
- $1.2 per 1,000 comments

#### Option 3: Chain Multiple Actors

1. Use `supreme_coder/linkedin-post` for post content
2. Chain with `curious_coder/linkedin-comment-scraper` for all comments

### Updated n8n Node Configuration

In your "Get post" Apify node, update the `customBody`:

```json
{
  "deepScrape": true,
  "limitPerSource": 1,
  "rawData": false,
  "maxComments": {{ $('LinkedIn Comment Form').item.json.maxComments || 50 }},
  "urls": [
    "{{ $json.postUrl }}"
  ]
}
```

### Accepting Extension Requests

Update your Form Trigger to accept requests from the Chrome extension by modifying it to handle CORS or using the webhook URL directly. The extension sends:

```json
{
  "LinkedIn Post URL": "https://www.linkedin.com/posts/...",
  "Number of Response Options": "3",
  "Tone": "Conversational",
  "maxComments": 50
}
```

## Usage

1. **Navigate to a LinkedIn Post** - Go to any LinkedIn post you want to comment on
2. **Open the Extension** - Click the extension icon or use the floating button on the page
3. **Configure Options**:
   - The URL should auto-fill (or paste manually)
   - Select number of response options (1-5)
   - Choose your preferred tone
4. **Generate** - Click "Generate Comments"
5. **Copy & Use** - Click copy on any generated comment to paste into LinkedIn

## File Structure

```
linkedin-comment-extension/
├── manifest.json        # Extension configuration
├── popup.html           # Main popup interface
├── popup.css            # Popup styles
├── popup.js             # Popup functionality
├── background.js        # Service worker
├── content.js           # LinkedIn page integration
├── content.css          # Floating button styles
├── icons/
│   ├── icon.svg         # Source icon
│   ├── icon16.png       # 16x16 icon
│   ├── icon32.png       # 32x32 icon
│   ├── icon48.png       # 48x48 icon
│   └── icon128.png      # 128x128 icon
└── README.md            # This file
```

## Troubleshooting

### "Please configure your n8n webhook URL"
You need to set up the webhook URL in settings. This is the URL from your n8n Form Trigger node.

### "Failed to generate comments"
- Check that your n8n workflow is active and running
- Verify the webhook URL is correct
- Ensure your n8n instance is accessible from the internet

### Extension not detecting LinkedIn posts
- Make sure you're on a LinkedIn post page (URL contains `/posts/` or `/feed/update/`)
- Try refreshing the page
- Check that the extension has permission for linkedin.com

### Only getting 10 comments analyzed
This is a limitation of the current Apify actor. See "Increasing Comment Limit" section above for solutions.

## Development

To modify the extension:

1. Make your changes to the source files
2. Go to `chrome://extensions/`
3. Click the refresh icon on the extension card
4. Test your changes

## Privacy

This extension:
- Only activates on linkedin.com pages
- Only sends data to YOUR configured n8n webhook
- Stores settings locally in Chrome sync storage
- Does not collect or transmit any personal data to third parties

## License

MIT License - Feel free to modify and distribute.
